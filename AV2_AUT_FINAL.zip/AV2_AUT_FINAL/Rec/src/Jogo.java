public class Jogo {

	public static void main(String[] args) {

		Interface game = new Interface();
		game.executar();

	}

}